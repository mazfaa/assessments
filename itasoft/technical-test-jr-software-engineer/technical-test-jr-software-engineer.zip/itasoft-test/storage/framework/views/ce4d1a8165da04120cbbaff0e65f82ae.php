

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Transaction Details')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
          <!-- Transaction Info -->
          <div class="mb-6">
            <h3 class="text-lg font-semibold">Transaction Information</h3>

            <table class="table w-1/2 mt-4">
              <tr>
                <th class="text-left">Transaction ID</th>
                <td>:</td>
                <td><?php echo e($transaction->id); ?></td>
              </tr>

              <tr>
                <th class="text-left">Customer Name</th>
                <td>:</td>
                <td><?php echo e($transaction->user->name); ?></td>
              </tr>

              <tr>
                <th class="text-left">Transaction Date</th>
                <td>:</td>
                <td><?php echo e($transaction->created_at->format('d M Y, H:i')); ?></td>
              </tr>

              <tr>
                <th class="text-left">Total Quantity</th>
                <td>:</td>
                <td><?php echo e($transaction->total_quantity); ?></td>
              </tr>

              <tr>
                <th class="text-left">Total Price</th>
                <td>:</td>
                <td>$<?php echo e(number_format($transaction->total_price, 2)); ?></td>
              </tr>
            </table>
          </div>

          <!-- Product Details -->
          <div>
            <h3 class="text-lg font-semibold">Products</h3>
            <div class="overflow-x-auto">
              <table class="min-w-full mt-4 border border-gray-200">
                <thead>
                  <tr class="bg-gray-100">
                    <th class="px-4 py-2 text-left">#</th>
                    <th class="px-4 py-2 text-left">Product Name</th>
                    <th class="px-4 py-2 text-left">Price</th>
                    <th class="px-4 py-2 text-left">Quantity</th>
                    <th class="px-4 py-2 text-left">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $total_price = 0; ?>
                  <?php $__currentLoopData = $transaction_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $product = $transaction->product ?>
                    <tr class="border-t">
                      <td class="px-4 py-2"><?php echo e($index + 1); ?></td>
                      <td class="px-4 py-2"><?php echo e($product->name); ?></td>
                      <td class="px-4 py-2">$<?php echo e(number_format($product->price, 2)); ?></td>
                      <td class="px-4 py-2"><?php echo e($transaction->quantity); ?></td>
                      <td class="px-4 py-2">$<?php echo e(number_format($product->price * $transaction->quantity, 2)); ?></td>
                      <?php $total_price += $product->price * $transaction->quantity ?>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td class="px-4 py-2 bg-gray-100" colspan="4">
                      Total
                    </td>
                    <td class="px-4 py-2 bg-gray-900 text-white">
                      $<?php echo e(number_format($total_price, 2)); ?>

                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Back Button -->
          <div class="mt-6">
            <a href="<?php echo e(route('transactions.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
              Back to Transactions
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\azfa\assessments\itasoft\technical-test-jr-software-engineer\itasoft-test\resources\views/transaction/item.blade.php ENDPATH**/ ?>