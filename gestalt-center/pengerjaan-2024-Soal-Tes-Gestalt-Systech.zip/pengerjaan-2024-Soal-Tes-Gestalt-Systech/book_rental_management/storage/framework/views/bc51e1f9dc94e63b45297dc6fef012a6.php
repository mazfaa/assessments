<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    <h5 class="card-title mb-0">Customers</h5>
    <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-sm badge btn-primary d-block ms-1"><i class="align-middle" data-feather="plus"></i> Create new customer</a>
   <?php $__env->endSlot(); ?>

  <table id="dataTable" class="display nowrap">
    <thead>
      <tr>
        <th>Name</th>
        <th>Identity Card Number</th>
        <th>Address</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($customer->name); ?></td>
          <td><?php echo e($customer->identity_card_number); ?></td>
          <td><?php echo e($customer->address); ?></td>
          <td>
            <a href="<?php echo e(route('customers.edit', $customer->id)); ?>" class="btn btn-sm badge btn-success">
              Edit
            </a>
            
            <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="post" class="d-inline-block">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <button class="btn btn-sm badge btn-danger" onclick="return confirm('Are you sure want to delete this customer?')">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH E:\azfa\practice\web\laravel\general\book_rental_management\resources\views/customers/index.blade.php ENDPATH**/ ?>