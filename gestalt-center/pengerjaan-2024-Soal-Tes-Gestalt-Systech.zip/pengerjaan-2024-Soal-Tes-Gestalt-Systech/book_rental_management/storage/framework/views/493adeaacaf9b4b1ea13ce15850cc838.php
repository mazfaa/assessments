<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    <h5 class="card-title mb-0">Books</h5>

    <div class="filter d-flex">
      <form action="<?php echo e(route('books.index')); ?>">
        <button type="submit" class="btn btn-sm badge btn-success"><i class="align-middle" data-feather="sliders"></i> All</button>
      </form>

      <form action="<?php echo e(route('books.unrented')); ?>" class="ms-1">
        <button type="submit" class="btn btn-sm badge btn-primary"><i class="align-middle" data-feather="sliders"></i> Books that have never been borrowed</button>
      </form>

      <form action="<?php echo e(route('books.filter')); ?>" class="ms-1">
        <button type="submit" class="btn btn-sm badge btn-dark"><i class="align-middle" data-feather="sliders"></i> Books priced at 2000-6000</button>
      </form>
      
      <a href="<?php echo e(route('books.create')); ?>" class="btn btn-sm badge btn-info d-block ms-1"><i class="align-middle" data-feather="plus"></i> Create new book</a>
    </div>
   <?php $__env->endSlot(); ?>

  <table id="dataTable" class="display nowrap">
    <thead>
      <tr>
        <th>Title</th>
        <th>Author</th>
        <th>Category</th>
        <th>Rent Status</th>
        <th>Price Rent</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($book->title); ?></td>
          <td><?php echo e($book->author); ?></td>
          <td><?php echo e($book->book_category); ?></td>
          
          <td>
            <?php if($book->rents->count() > 0): ?>
              <span class="badge text-bg-success text-white">Rented</span>
            <?php else: ?>
              <span class="badge text-bg-primary text-white">Available</span>
            <?php endif; ?>
          </td>

          <td><?php echo e($book->price_rent); ?></td>

          <td>
            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-sm badge btn-success">
              Edit
            </a>

            <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="post" class="d-inline-block">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <button class="btn btn-sm badge btn-danger" onclick="return confirm('Are you sure want to delete this book?')">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH E:\azfa\practice\web\laravel\general\book_rental_management\resources\views/books/index.blade.php ENDPATH**/ ?>