<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    <h5 class="card-title mb-0">Rentals</h5>
    <a href="<?php echo e(route('rents.create')); ?>" class="btn btn-sm badge btn-primary d-block ms-1"><i class="align-middle" data-feather="plus"></i> Create new rent</a>
   <?php $__env->endSlot(); ?>

  <table id="dataTable" class="display nowrap">
    <thead>
      <tr>
        <th>Book Title</th>
        <th>Book Author</th>
        <th>Customer Name</th>
        <th>Rent Date</th>
        <th>Return Date</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($rent->book->title); ?></td>
          <td><?php echo e($rent->book->author); ?></td>
          <td><?php echo e($rent->customer->name); ?></td>
          <td>
            <span class="badge text-bg-success text-white"><?php echo e($rent->date_rent); ?></span>
          </td>
          <td>
             <span class="badge <?php echo e($rent->date_return ? 'text-bg-primary' : 'text-bg-danger'); ?> text-white">
                <?php echo e($rent->date_return ?? 'Not returned yet'); ?>

            </span>
          </td>

          <td class="d-flex">
            <a href="<?php echo e(route('rents.edit', ['rent' => $rent->id, 'customer' => $rent->customer->id, 'book' => $rent->book->id])); ?>" class="btn btn-sm badge btn-success">
              Edit
            </a>

            <a href="<?php echo e(route('rents.setAsReturned', $rent->id)); ?>" class="btn btn-sm badge btn-primary ms-1">
              Set as returned
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH E:\azfa\practice\web\laravel\general\book_rental_management\resources\views/rents/index.blade.php ENDPATH**/ ?>